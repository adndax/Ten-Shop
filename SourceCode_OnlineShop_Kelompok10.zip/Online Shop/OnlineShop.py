import tkinter as tk
from tkinter import simpledialog, messagebox

# menentukan fungsi untuk memilih item

def PilihBarang():
    def choose_items():
        input_barang = int(entry_barang.get())
        if 1 <= input_barang <= 7:
            input_ukuran = entry_ukuran.get().upper()
            if input_ukuran in ["S", "M", "L", "XL"]:
                barang_dipilih.append(input_barang)
                harga_barang_dipilih.append(harga[input_barang])
                ukuran_dipilih.append(input_ukuran)
                update_item_list()
            else:
                error_label.config(text="Maaf, ukuran tidak tersedia. Silahkan pilih kembali ukuran yang ingin Anda pilih (S/M/L/XL).")
        else:
            error_label.config(text="Maaf, barang tidak tersedia. Silahkan pilih kembali barang yang ingin Anda beli (1-7).")


    def update_item_list():
        item_list.delete(0, tk.END)
        for i, item in enumerate(barang_dipilih, start=1):
            size = ukuran_dipilih[i-1] if i <= len(ukuran_dipilih) and ukuran_dipilih[i-1] in ["S", "M", "L", "XL"] else "Invalid size (S/M/L/XL only)"
            item_list.insert(tk.END, f"{i}. {barang[item]} ({size})")


    # membuat window Tkinter baru
    item_window = tk.Toplevel()
    item_window.title("Pilih Barang")
    
    # membuat label dan entry untuk memilih barang
    select_label = tk.Label(item_window, text="Silahkan masukkan nomor barang yang akan dibeli (1-7):")
    entry_barang = tk.Entry(item_window)
    
    # membuat label dan entry untuk memilih ukuran
    size_label = tk.Label(item_window, text="Silahkan masukkan ukuran yang akan dipilih (S/M/L/XL):")
    entry_ukuran = tk.Entry(item_window)
    
    # membuat tombol untuk menambah barang
    choose_button = tk.Button(item_window, text="Tambah Barang", command=choose_items)
    
    # membuat list untuk menampilkan barang yang dipilih
    item_list = tk.Listbox(item_window, selectmode=tk.SINGLE, height=10, width=40)
    
    # membuat label untuk pesan error
    error_label = tk.Label(item_window, text="", fg="red")
    
    # membuat tombol untuk menyelesaikan tahap pemilihan barang
    continue_button = tk.Button(item_window, text="Barang Pilihan Telah Sesuai", command=item_window.destroy)
    
    # menulis method pack untuk menampilkan widgets
    select_label.pack()
    entry_barang.pack()
    size_label.pack()
    entry_ukuran.pack()
    choose_button.pack()
    item_list.pack()
    error_label.pack()
    continue_button.pack()

# menentukan fungsi untuk mengonfirmasi pembayaran

def confirm_payment():

    # mengalkulasikan harga total dari semua barang yang telah dipilih
    harga_total = sum(harga_barang_dipilih)

    # menampilkan dialog untuk memasukkan alamat pengiriman
    alamat = simpledialog.askstring("Alamat", "Masukkan alamat yang ingin dituju pengiriman:")
    
    # percabangan
    if alamat: # jika alamat tidak kosong

        # menampilkan dialog untuk memasukkan metode pembayaran
        payment_method = simpledialog.askstring("Pembayaran", "Masukkan metode pembayaran (BCA/Gopay/Dana):")

        if payment_method: # jika metode pembayaran tidak kosong
            payment_method = payment_method.upper()

            # mengecek apakah metode pembayaran sesuai
            if payment_method in ["BCA", "GOPAY", "DANA"]:

                # mengeset expected amount sama dengan harga total
                # expected amount adalah jumlah inputan uang yang diharapkan
                expected_amount = harga_total

                # menampilkan dialog untuk memasukkan jumlah uang yang dibayarkan
                amount_paid = simpledialog.askinteger("Pembayaran", f"Masukkan jumlah uang yang ingin Anda bayarkan | Total (Rp {expected_amount}):")
                
                # jika jumlah uang tidak kosong
                if amount_paid is not None:

                    # mengecek apakah jumlah uang sesuai harapan
                    if amount_paid == expected_amount: # jika iya
                        confirmation_message = f"Transaksi Anda melalui {payment_method} sebesar {expected_amount} telah berhasil. Pesanan Anda akan segera diproses dan dikirimkan ke {alamat}. Terima kasih."
                        messagebox.showinfo("Konfirmasi Pembayaran", confirmation_message)
                    else: # jika tidak
                        messagebox.showerror("Error", "Maaf, uang yang dibayarkan harus merupakan uang pas.")

            else: # jika metode pembayaran tidak sesuai
                messagebox.showerror("Error", "Maaf, metode pembayaran yang dimasukkan tidak valid.")

        else: # jika metode pembayaran kosong
            messagebox.showerror("Error", "Maaf, metode pembayaran tidak boleh kosong.")

    else: # jika alamat kosong
        messagebox.showerror("Error", "Maaf, alamat tidak boleh kosong.")

# menyetel window
window = tk.Tk()
window.title("Online Shop")

# membuat label selamat datang
welcome_label = tk.Label(window, text="Selamat datang di Ten Shop!\nBerikut harga dan ukuran dari barang yang kami jual.")
welcome_label.pack()

# membuat frame untuk informasi barang yang dijual
product_info_frame = tk.Frame(window)
product_info_frame.pack()

# mendefinisikan informasi produk beserta gambarnya
product_info = [
    ("No", "Nama Barang", "Harga Barang (Rp)", "Ukuran", "Image Path"),
    (1, "Knit Cardigan", 100000, "S, M, L, XL", "knit_cardigan.png"),
    (2, "Longsleeve", 70000, "S, M, L, XL", "longsleeve.png"),
    (3, "Denim Jacket", 200000, "S, M, L, XL", "jeans_jacket.png"),
    (4, "Varsity Jacket", 350000, "S, M, L, XL", "varsity_jacket.png"),
    (5, "Midi Skirt", 90000, "S, M, L, XL", "midi_skirt.png"),
    (6, "Baggy Jeans", 185000, "S, M, L, XL", "baggy_jeans.png"),
    (7, "Jogger Pants", 150000, "S, M, L, XL", "jogger_pants.png"),
]

# membuat dictionary untuk memetakan produk ke alamat gambar
image_paths = {product[1]: product[4] for product in product_info[1:]}

# membuat dan menampilkan label untuk informasi produk beserta gambarnya
for row, data in enumerate(product_info):
    for col, value in enumerate(data):
        if col == 4:  # kolom gambar
            product_name = product_info[row][1]
            image_path = image_paths.get(product_name)
 
            if image_path:
                image = tk.PhotoImage(file=image_path)
                image_label = tk.Label(product_info_frame, image=image)
                image_label.image = image  # Keep a reference to the image
                image_label.grid(row=row, column=col, padx=5, pady=5)
        else:
            label = tk.Label(product_info_frame, text=str(value))
            label.grid(row=row, column=col, padx=5, pady=5)

# mendefinisikan item dalam list
barang = ["Nama Barang", "Knit Cardigan", "Longsleeve", "Denim Jacket", "Varsity Jacket",
          "Midi Skirt", "Baggy Jeans", "Jogger Pants"]
nomor = [i for i in range(1, len(barang))]
nomor.insert(0, "No")
harga = [100000, 70000, 200000, 350000, 90000, 185000, 150000]
harga.insert(0, "Harga Barang (Rp)")
size = ["S, M, L, XL" for i in range(1, len(barang) + 1)]
size.insert(0, "Ukuran")

# membuat tombol untuk setiap fungsi
choose_item_button = tk.Button(window, text="Pilih Barang", command=PilihBarang)
confirm_payment_button = tk.Button(window, text="Konfirmasi Pembayaran", command=confirm_payment)
choose_item_button.pack()
confirm_payment_button.pack()

# membuat list untuk barang yang dipilih beserta harga dan ukurannya
barang_dipilih = []
harga_barang_dipilih = []
ukuran_dipilih = []

# Run aplikasi the Tkinter 
window.mainloop()